package com.example.demo.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.security.core.userdetails.User;
import com.example.demo.Etity.Member;
import com.example.demo.Repo.MemberRepository;

@Service
public class MemberService {

    @Autowired
    private MemberRepository memberRepository;

    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Member member = memberRepository.findByUserId(username);
        if (member == null || !member.isActive()) {
            throw new UsernameNotFoundException("User not found or not active");
        }
        return User.withUsername(member.getUserId())
                   .password(member.getPassword())
                   .roles("ADMIN") // Bạn có thể thêm các role ở đây
                   .build();
    }
}
