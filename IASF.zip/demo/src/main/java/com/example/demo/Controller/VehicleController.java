package com.example.demo.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Etity.Vehicle;
import com.example.demo.Service.VehicleService;
import org.springframework.ui.Model;

@Controller
@RequestMapping("/vehicles")
public class VehicleController {

    @Autowired
    private VehicleService vehicleService;

    @GetMapping
    public String listVehicles(Model model) {
        model.addAttribute("vehicles", vehicleService.getAllVehicles());
        return "vehicle/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("vehicle", new Vehicle());
        return "vehicle/add";
    }

    @PostMapping("/add")
    public String addVehicle(@ModelAttribute Vehicle vehicle) {
        vehicleService.addVehicle(vehicle);
        return "redirect:/vehicles";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Integer id, Model model) {
        Vehicle vehicle = vehicleService.getAllVehicles().stream()
                .filter(v -> v.getVehicleId().equals(id))
                .findFirst()
                .orElse(null);
        model.addAttribute("vehicle", vehicle);
        return "vehicle/edit";
    }

    @PostMapping("/edit")
    public String updateVehicle(@ModelAttribute Vehicle vehicle) {
        vehicleService.updateVehicle(vehicle);
        return "redirect:/vehicles";
    }

    @GetMapping("/delete/{id}")
    public String deleteVehicle(@PathVariable Integer id) {
        vehicleService.deleteVehicle(id);
        return "redirect:/vehicles";
    }
}