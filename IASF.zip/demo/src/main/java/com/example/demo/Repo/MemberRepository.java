package com.example.demo.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Etity.Member;
@Repository
public interface MemberRepository extends JpaRepository<Member, String> {
    Member findByUserId(String userId);
}