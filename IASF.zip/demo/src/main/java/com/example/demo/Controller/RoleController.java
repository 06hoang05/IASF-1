package com.example.demo.Controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.demo.Etity.Role;
import com.example.demo.Service.RoleService;

@Controller
@RequestMapping("/roles")
public class RoleController {

    @Autowired
    private RoleService roleService;

    @GetMapping
    public String listRoles(Model model) {
        model.addAttribute("roles", roleService.getAllRoles());
        return "role/list";
    }

    @GetMapping("/add")
    public String showAddForm(Model model) {
        model.addAttribute("role", new Role());
        return "role/add";
    }

    @PostMapping("/add")
    public String addRole(@ModelAttribute Role role) {
        roleService.addRole(role);
        return "redirect:/roles";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        model.addAttribute("role", roleService.getAllRoles().stream()
                .filter(r -> r.getId().equals(id))
                .findFirst()
                .orElse(null));
        return "role/edit";
    }

    @PostMapping("/edit")
    public String updateRole(@ModelAttribute Role role) {
        roleService.updateRole(role);
        return "redirect:/roles";
    }

    @GetMapping("/delete/{id}")
    public String deleteRole(@PathVariable Long id) {
        roleService.deleteRole(id);
        return "redirect:/roles";
    }
}