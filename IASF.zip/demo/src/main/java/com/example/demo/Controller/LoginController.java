package com.example.demo.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class LoginController {

    @GetMapping("/login")
    public String login() {
        return "login";  // Trả về view login.jsp
    }

    @GetMapping("/logout")
    public String logout() {
        return "redirect:/login?logout";  // Điều hướng về trang login sau khi logout
    }

    @GetMapping("/")
    public String home() {
        return "redirect:/vehicles";  // Trang chính sau khi đăng nhập thành công
    }
}
